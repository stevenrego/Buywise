import ShareClient from './shareClient'
export default function SharePage({ searchParams }: { searchParams: { title?: string; text?: string; url?: string } }) {
  const shared = [searchParams.title, searchParams.text, searchParams.url].filter(Boolean).join('\n')
  return <ShareClient shared={shared} />
}
