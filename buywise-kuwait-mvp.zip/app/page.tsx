'use client'

import { useState } from 'react'
import { ShoppingBag, Share2, Sparkles, Bookmark } from 'lucide-react'

type Analysis = {
  verdict: 'BUY' | 'WAIT' | 'AVOID'
  score: number
  productName: string
  summary: string
  pros: string[]
  cons: string[]
  redFlags: string[]
  kuwaitNotes: string[]
  betterAlternatives: string[]
}

function saveItem(input: string, analysis: Analysis) {
  const current = JSON.parse(localStorage.getItem('buywise_saved') || '[]')
  localStorage.setItem('buywise_saved', JSON.stringify([{ input, analysis, savedAt: new Date().toISOString() }, ...current]))
}

export default function Home() {
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [analysis, setAnalysis] = useState<Analysis | null>(null)
  const [error, setError] = useState('')

  async function analyze() {
    setError('')
    setLoading(true)
    setAnalysis(null)
    try {
      const res = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ input })
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Analysis failed')
      setAnalysis(data)
    } catch (e: any) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  return <main className="container">
    <header className="header">
      <div className="row"><div className="logo">B</div><div><b>BuyWise Kuwait</b><div className="muted">Share anything. Decide fast.</div></div></div>
      <nav className="nav"><a href="/saved">Saved</a></nav>
    </header>

    <section className="card" style={{marginBottom:16}}>
      <div className="pill"><Sparkles size={14}/> AI buying decision engine</div>
      <h1 style={{fontSize:48,lineHeight:1,letterSpacing:-2,margin:'18px 0'}}>Check before you buy.</h1>
      <p className="muted" style={{fontSize:18}}>Paste a product link, Instagram/TikTok link, WhatsApp shop link, or product description. On Android PWA, install the app and use Share → BuyWise.</p>
      <textarea value={input} onChange={e=>setInput(e.target.value)} placeholder="Paste product link or description here..." />
      <div className="row" style={{marginTop:12}}>
        <button className="btn" onClick={analyze} disabled={loading || !input.trim()}>{loading ? 'Checking...' : 'Analyze'}</button>
        <a className="btn secondary" href="/saved"><Bookmark size={16}/> Saved items</a>
      </div>
      {error && <p className="danger">{error}</p>}
    </section>

    <section className="grid">
      <div className="card"><Share2/><h3>Share from anywhere</h3><p className="muted">Instagram, TikTok, browsers, marketplaces, and WhatsApp links.</p></div>
      <div className="card"><ShoppingBag/><h3>Kuwait-first logic</h3><p className="muted">Verdict considers availability, local warranty, delivery, returns, and overpricing risk.</p></div>
    </section>

    {analysis && <section className="card" style={{marginTop:16}}>
      <div className="row" style={{justifyContent:'space-between'}}>
        <div><div className="muted">Verdict</div><div className={`verdict ${analysis.verdict === 'BUY' ? 'ok' : analysis.verdict === 'WAIT' ? 'warn' : 'danger'}`}>{analysis.verdict}</div></div>
        <div><div className="muted">Score</div><div className="score">{analysis.score}</div></div>
      </div>
      <h2>{analysis.productName}</h2>
      <p>{analysis.summary}</p>
      <div className="grid">
        <div><h3>Pros</h3><ul className="list">{analysis.pros.map((x,i)=><li key={i}>{x}</li>)}</ul></div>
        <div><h3>Cons</h3><ul className="list">{analysis.cons.map((x,i)=><li key={i}>{x}</li>)}</ul></div>
        <div><h3>Red flags</h3><ul className="list">{analysis.redFlags.map((x,i)=><li key={i}>{x}</li>)}</ul></div>
        <div><h3>Kuwait notes</h3><ul className="list">{analysis.kuwaitNotes.map((x,i)=><li key={i}>{x}</li>)}</ul></div>
      </div>
      <h3>Better alternatives</h3>
      <ul className="list">{analysis.betterAlternatives.map((x,i)=><li key={i}>{x}</li>)}</ul>
      <button className="btn" onClick={() => saveItem(input, analysis)}>Save this item</button>
    </section>}
  </main>
}
