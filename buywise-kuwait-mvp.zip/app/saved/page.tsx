'use client'
import { useEffect, useState } from 'react'

type Item = { input: string; savedAt: string; analysis: { verdict: string; score: number; productName: string; summary: string } }
export default function Saved() {
  const [items, setItems] = useState<Item[]>([])
  useEffect(()=>{ setItems(JSON.parse(localStorage.getItem('buywise_saved') || '[]')) }, [])
  return <main className="container">
    <header className="header"><div><b>Saved Items</b><div className="muted">Products and reels you saved.</div></div><a href="/">Home</a></header>
    <div className="grid">
      {items.length === 0 && <div className="card"><h2>No saved items yet</h2><p className="muted">Analyze something and save it.</p></div>}
      {items.map((it, i)=><div className="card" key={i}>
        <div className="pill">{it.analysis.verdict} · {it.analysis.score}/100</div>
        <h3>{it.analysis.productName}</h3>
        <p className="muted">{it.analysis.summary}</p>
        <small className="muted">{new Date(it.savedAt).toLocaleString()}</small>
      </div>)}
    </div>
  </main>
}
