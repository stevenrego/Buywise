import { NextRequest, NextResponse } from 'next/server'

function fallback(input: string) {
  return {
    verdict: 'WAIT',
    score: 68,
    productName: input.slice(0, 80) || 'Shared product',
    summary: 'Demo mode: add OPENAI_API_KEY in Vercel to enable real AI analysis. This placeholder shows the expected response structure.',
    pros: ['Fast check flow', 'Works with shared links or product descriptions', 'Kuwait-specific decision format'],
    cons: ['Live price comparison is not connected yet', 'Instagram video extraction needs a native app or approved scraping/API flow'],
    redFlags: ['Do not trust influencer claims without independent review data', 'Check warranty and return policy before buying'],
    kuwaitNotes: ['Compare with Xcite, Eureka, Blink, Best Al Yousifi, Lulu, Carrefour, and Amazon UAE where relevant', 'Check whether warranty is Kuwait-local or international only'],
    betterAlternatives: ['Add merchant database in Phase 2', 'Add affiliate sources in Phase 3']
  }
}

export async function POST(req: NextRequest) {
  try {
    const { input } = await req.json()
    if (!input || typeof input !== 'string') {
      return NextResponse.json({ error: 'Input is required' }, { status: 400 })
    }

    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json(fallback(input))
    }

    const prompt = `You are BuyWise Kuwait, an unbiased shopping decision engine for Kuwait. Analyze the shared product/link/reel text. Return only valid JSON with: verdict BUY/WAIT/AVOID, score 0-100, productName, summary, pros array, cons array, redFlags array, kuwaitNotes array, betterAlternatives array. Be concise. Consider local warranty, return risk, influencer hype, availability, overpricing, and whether the user should wait. Input: ${input}`

    const response = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || 'gpt-4.1-mini',
        input: prompt,
        text: { format: { type: 'json_object' } }
      })
    })

    if (!response.ok) {
      const err = await response.text()
      return NextResponse.json({ error: `OpenAI error: ${err}` }, { status: 500 })
    }

    const data = await response.json()
    const text = data.output_text || data.output?.[0]?.content?.[0]?.text
    return NextResponse.json(JSON.parse(text))
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Server error' }, { status: 500 })
  }
}
