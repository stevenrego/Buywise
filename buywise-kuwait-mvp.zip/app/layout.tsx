import './globals.css'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'BuyWise Kuwait',
  description: 'Share anything you see online and get an instant buy decision.',
  manifest: '/manifest.json',
  themeColor: '#0b0f17',
  appleWebApp: { capable: true, title: 'BuyWise' }
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>
}
