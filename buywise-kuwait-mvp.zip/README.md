# BuyWise Kuwait MVP

A near-free MVP for a Kuwait-focused AI shopping assistant.

## What it does

- Paste product link or description
- Install as PWA and use Android Share → BuyWise for links/text
- AI returns BUY / WAIT / AVOID verdict
- Saved products stored in browser localStorage
- No wallet, no payments, no regulated financial flow

## Tech stack

- Next.js app router
- Vercel Hobby deployment
- OpenAI API for verdicts
- Browser localStorage for saved items in MVP

## One-click deployment

### Option A: fastest Vercel import

1. Create a GitHub repo named `buywise-kuwait-mvp`.
2. Upload all files in this folder.
3. Go to Vercel → Add New Project → Import GitHub repo.
4. Add environment variable:
   - `OPENAI_API_KEY=your_key_here`
   - optional: `OPENAI_MODEL=gpt-4.1-mini`
5. Click Deploy.
6. Open the site on Android Chrome → Add to Home Screen.
7. Share any link/text from another app → BuyWise should appear as a share target after installation.

### Option B: deploy from terminal

```bash
npm install
npm run build
npx vercel
```

Then add the same environment variables in Vercel dashboard.

## Local development

```bash
npm install
npm run dev
```

Open `http://localhost:3000`.

## Important limitations

- Instagram/TikTok video downloading is not included. Do not scrape private or restricted content.
- The PWA share target is strongest on Android/Chrome. iOS share-extension behavior requires a native app wrapper.
- Real price comparison requires merchant APIs, approved scraping, affiliate feeds, or a curated merchant catalog.
- For production, replace localStorage with Supabase/Postgres and add authentication.

## Suggested Phase 2

- Supabase Auth
- Supabase database for saved products
- Merchant price table
- Admin dashboard
- Affiliate tracking
- Native mobile app using React Native/Expo for reliable iOS/Android share extensions
